# DEPRECATED

This Button implementation has been deprecated and replaced with shadcn/ui Button.

All ActionButton components now use `@/components/ui/button` instead.

This directory can be safely deleted.