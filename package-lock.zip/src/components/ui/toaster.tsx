// DEPRECATED: This file has been replaced with Sonner toast library
// Use: import { Toaster } from 'sonner' instead
// This file can be safely deleted

throw new Error('toaster.tsx is deprecated. Use `import { Toaster } from "sonner"` instead')