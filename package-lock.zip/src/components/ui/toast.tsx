// DEPRECATED: This file has been replaced with Sonner toast library
// Use: import { toast } from 'sonner' instead
// This file can be safely deleted

throw new Error('toast.tsx is deprecated. Use `import { toast } from "sonner"` instead')