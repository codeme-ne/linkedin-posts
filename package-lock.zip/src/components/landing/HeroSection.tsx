import { useMemo } from "react";
import { Button } from "@/components/ui/button";
import { useTypewriter } from "@/hooks/useTypewriter";

type HeroSectionProps = {
  isVisible: boolean;
  onSignup: () => void;
};

export function HeroSection({ isVisible, onSignup }: HeroSectionProps) {
  const phrases = useMemo(() => ([
    { text: "LinkedIn Post", color: "text-[#0a66c2]" },
    { text: "Twitter Thread", color: "text-black dark:text-white" },
    { text: "Instagram Story", color: "text-[#e706ab]" }
  ]), []);

  const { displayText, currentIndex } = useTypewriter(phrases.map(p => p.text), { enabled: true });

  return (
    <div className={`space-y-6 md:space-y-8 transition-all duration-700 delay-100 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
      <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold leading-tight tracking-tight">
        <span className="text-foreground">Mach aus jedem Text einen</span>
        <br />
        <span className={`${phrases[currentIndex].color} transition-colors duration-300`}>
          {displayText}
          <span className="animate-pulse">|</span>
        </span>
      </h1>
      <p className="text-base sm:text-lg md:text-xl leading-relaxed text-muted-foreground max-w-2xl">
        <span className="font-semibold">Spare 15 Minuten pro Post.</span> Füge beliebigen Text oder eine URL ein und 
        erhalte sofort perfekt formatierte Social-Media-Beiträge für alle Plattformen. 
      </p>
      <div className="flex flex-col sm:flex-row gap-4 pt-2 md:pt-4">
        <Button 
          size="lg" 
          className="w-full sm:w-auto bg-gradient-to-r from-primary to-accent hover:from-primary/90 hover:to-accent/90 text-white font-semibold shadow-lg shadow-primary/20 hover:shadow-xl hover:scale-105 transition-all duration-300 px-8 py-6 text-base sm:text-lg" 
          onClick={onSignup}
        >
          Kostenlos testen →
        </Button>
      </div>
    </div>
  );
}
