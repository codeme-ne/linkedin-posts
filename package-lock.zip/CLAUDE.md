# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Social Transformer is a SaaS application that transforms newsletters and blog posts into platform-optimized social media content using Claude AI. The app features a freemium model with 2 transformations/day for free users and unlimited for Pro subscribers (€49 lifetime deal).

## Development Commands

### Local Development
```bash
# Standard development (recommended for most work)
npm run dev              # Starts Vite dev server on port 5173

# Production-like development (for testing API routes)
vercel dev --yes         # Starts Vercel dev server on port 3000 with serverless functions
```

**Important**: Use `vercel dev` when testing API routes (`/api/*`) as they are Vercel serverless functions that don't work with regular Vite dev server.

### Build & Quality
```bash
npm run build           # TypeScript compilation + Vite build
npm run preview         # Preview production build
npm run lint            # ESLint check
```

## Architecture Overview

### Frontend Structure
- **App Router**: React Router 7 with lazy-loaded pages
- **Authentication Flow**: Public routes (/, /signup, /privacy, /terms) → Protected routes (/app, /settings)
- **Core Pages**:
  - `Landing` - Marketing page with pricing and features
  - `Generator` - Main app functionality (content transformation)
  - `Settings` - User account management
- **Design System**: Located in `/src/design-system/` using shadcn/ui + custom components
- **State Management**: React hooks + Supabase real-time subscriptions

### Backend Architecture (Vercel Serverless Functions)
```
/api
├── extract.ts              # Free content extraction (Jina Reader)
├── extract-premium.ts      # Premium content extraction with AI
├── claude/v1/messages.ts   # Claude AI proxy endpoint
├── stripe-webhook.ts       # Stripe payment processing
├── reconcile-subscription.ts # Subscription activation
└── stripe/                 # Stripe customer portal endpoints
```

### Database Schema (Supabase)
- `subscriptions` - User payment status and limits
- `generation_usage` - Daily usage tracking for free users
- `saved_posts` - User's generated and saved content
- `pending_subscriptions` - Payment reconciliation table

### Key Integration Points

**Content Extraction Flow**:
1. Frontend calls `/api/extract` with URL
2. Jina Reader fetches and cleans content  
3. Content processed through Claude AI via `/api/claude/v1/messages`
4. Results displayed with platform-specific optimization options

**Subscription Flow**:
1. Stripe payment link → checkout
2. Webhook calls `/api/stripe-webhook` 
3. Creates `pending_subscriptions` record
4. User login triggers `/api/reconcile-subscription`
5. Activates unlimited usage

## Environment Configuration

### Required Variables
```bash
# Client-side (VITE_ prefix)
VITE_SUPABASE_URL=
VITE_SUPABASE_ANON_KEY=
VITE_STRIPE_PAYMENT_LINK=

# Server-side (Vercel functions)
CLAUDE_API_KEY=
SUPABASE_URL=
SUPABASE_SERVICE_ROLE_KEY=
STRIPE_WEBHOOK_SECRET=

# Optional LinkedIn integration
VITE_LINKEDIN_ACCESS_TOKEN=
VITE_LINKEDIN_AUTHOR_URN=
```

## Development Patterns

### API Route Development
- All serverless functions use Edge Runtime for performance
- Error handling follows consistent pattern with proper HTTP status codes
- CORS configured for `http://localhost:5173` (Vite) and `http://localhost:3000` (Vercel)

### Component Architecture
- `/src/components/` - Reusable components organized by feature
- `/src/design-system/` - Design system components and action buttons
- `/src/pages/` - Route-level components (lazy-loaded)
- Consistent use of TypeScript interfaces for props and API responses

### Authentication & Authorization
- Supabase Auth with email/password
- `ProtectedRoute` wrapper for authenticated pages
- Usage limits enforced via database triggers and API checks

## Database Development

Migrations are located in `/supabase/migrations/` and should be run in order:
1. `000_create_subscriptions_table.sql` - Core subscription tracking
2. `001_create_generation_usage_table.sql` - Usage limits
3. `002_extend_subscriptions_table.sql` - Additional subscription fields
4. `003_create_pending_subscriptions.sql` - Payment reconciliation
5. `004_add_is_active_column.sql` & `005_rollback_is_active_column.sql` - Schema updates

## Deployment Notes

- **Platform**: Vercel (automatic GitHub deployment)
- **Database**: Supabase hosted PostgreSQL
- **Payments**: Stripe with webhook integration
- **AI**: Anthropic Claude API proxied through serverless functions
- **Environment**: All VITE_ variables + server-side secrets in Vercel dashboard

## Known Development Issues

When using `vercel dev`, you may encounter Vite module loading issues with MIME types. If this occurs, use the standard `npm run dev` for frontend development and deploy to staging to test API integration.